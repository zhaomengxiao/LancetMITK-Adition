#ifndef LancetTest_H
#define LancetTest_H

#include <QObject>
#include "org_mitk_lancet_services_empty_Export.h"

class ORG_MITK_LANCET_SERVICES_EMPTY_PLUGIN lancetTest : public QObject
{
	Q_OBJECT
public:
	lancetTest();
};
#endif // !LancetTest_H
