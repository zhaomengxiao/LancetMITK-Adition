#include "lancetTest.h"

lancetTest::lancetTest()
{}