﻿#pragma execution_character_set("utf-8")
// Blueberry
#include <berryISelectionService.h>
#include <berryIWorkbenchWindow.h>

// Qt
#include <QDebug>
#include <QMessageBox>
//#include "ReadBackups.h"

#include <QMessageBox>
#include <QFileInfo>
#include <QFileDialog>
#include <QRegExpValidator>
#include "QMedicalRecordInfoDialog.h"
#include "ui_QMedicalRecordInfoDialog.h"
#include <QFile>
#include <QFileInfo>
#include <QTextCodec>
#include <QJsonValue> 
#include <QJsonObject> 
#include <QJsonDocument>
#include <QJsonParseError>

// lancet
#include <QPluginLoader>
#include <QTimer>
#include <QPluginLoader>
#include <lancetIMedicalRecordsScanner.h>
#include <lancetIMedicalRecordsProperty.h>
#include <lancetIMedicalRecordsAdministrationService.h>
QMedicalRecordInfoDialog::QMedicalRecordInfoDialog(QWidget* parent)
	: QDialog(parent), m_Controls(new Ui::QMedicalRecordInfoDialog)
{
	m_Controls->setupUi(this);
	QRegExp regx("[1-9][0-9]+$");
	QValidator* validator_patientAge = new QRegExpValidator(regx, m_Controls->lineEdit_patientAge);
	m_Controls->lineEdit_patientAge->setValidator(validator_patientAge);
	connect(m_Controls->pushButton_browse, &QPushButton::clicked, this, &QMedicalRecordInfoDialog::on_pushButton_browse_clicked);
	connect(m_Controls->pushButton_done, &QPushButton::clicked, this, &QMedicalRecordInfoDialog::on_pushButton_done_clicked);

}

QMedicalRecordInfoDialog::~QMedicalRecordInfoDialog()
{
	delete m_Controls;
}

void QMedicalRecordInfoDialog::ModifyInfo(int row, lancet::IMedicalRecordsProperty* data)
{

}

void QMedicalRecordInfoDialog::CreateInfo(int index, lancet::IMedicalRecordsProperty* data)
{
	qDebug() << "QMedicalRecordInfoDialog:" << __func__ << ": log";
	QDir workDir(QDir::currentPath());
	workDir.cd("..");
	workDir.cd("..");
	workDir.cd("bin");
	workDir.cd("planning"); 
	QFile fp(workDir.absoluteFilePath(QString("test.json")));
	
//	m_Controls->comboBox_patientGender->setCurrentText(info.patient_gender);
//	m_Controls->comboBox_surgerySide->setCurrentText(info.surgery_side);
//	m_Controls->lineEdit_patientName->setText(info.patient_name);
//	m_Controls->lineEdit_patientID->setText(info.patient_id);	
//	m_Controls->lineEdit_patientAge->setText(QString::number(info.patient_age));
//	m_Controls->lineEdit_surgeryOperator->setText(info.surgery_operator);
//	m_Controls->lineEdit_caseDirectory->setText(info.case_dir);
}

void QMedicalRecordInfoDialog::clearData()
{
	m_Controls->comboBox_patientGender->setCurrentText(0);
	m_Controls->comboBox_surgerySide->setCurrentIndex(0);
	m_Controls->lineEdit_patientName->setText("");
	m_Controls->lineEdit_patientID->setText("");
	m_Controls->lineEdit_patientAge->setText("");
	m_Controls->lineEdit_surgeryOperator->setText("");
	m_Controls->lineEdit_caseDirectory->setText("");
}

void QMedicalRecordInfoDialog::on_pushButton_browse_clicked()
{
	qDebug() << "QMedicalRecordInfoDialog:" << __func__ << ": log";
	/*ReadBackups::DataDir = QFileDialog::getExistingDirectory(this, "请选择影像路径...", ".");
	if (ReadBackups::DataDir.isEmpty())
	{
		QMessageBox::information(NULL, "提示", "请输入患者CT数据地址！", "关闭");
		return;
	}
	else 
	{
		m_Controls->lineEdit_caseDirectory->setText(ReadBackups::DataDir);
	}
	Log::write("QMedicalRecordInfoDialog::on_pushButton_browse_clicked" + ReadBackups::DataDir);*/
}

void QMedicalRecordInfoDialog::on_pushButton_done_clicked()
{
	qDebug() << "QMedicalRecordInfoDialog:" << __func__ << ": log";
	if (m_Controls->lineEdit_patientName->text().isEmpty())
	{
		QMessageBox::information(NULL, "提示","请输入患者姓名！","关闭");
		return;
	}

	if (m_Controls->lineEdit_patientID->text().isEmpty())
	{
		QMessageBox::information(NULL,"提示", "请输入患者ID！", "关闭");
		return;
	}
	if (m_Controls->lineEdit_patientAge->text().isEmpty())
	{
		QMessageBox::information(NULL, "提示","请输入患者年龄！", "关闭");
		return;
	}
	if (m_Controls->lineEdit_surgeryOperator->text().isEmpty())
	{
		QMessageBox::information(NULL, "提示", "请输入医生姓名！", "关闭");
		return;
	}
	
	if (m_Controls->lineEdit_caseDirectory->text().isEmpty())
	{
		QMessageBox::information(NULL, "提示", "请输入患者CT数据地址！", "关闭");
		return;
	}
	/*lancet::IMedicalRecordsProperty* data;
	if (!data < 0)
	{
		return;
	}
	m_Controls->lineEdit_patientName->setText(data->GetKeyValue(0).toString());
	m_Controls->lineEdit_patientID->setText(data->GetKeyValue(0).toString());
	m_Controls->comboBox_patientGender->setCurrentText(data->GetKeyValue(0).toString());
	m_Controls->comboBox_surgerySide->setCurrentIndex(0);
	m_Controls->lineEdit_patientAge->setText(data->GetKeyValue(0).toString());
	m_Controls->lineEdit_surgeryOperator->setText(data->GetKeyValue(0).toString());
	m_Controls->lineEdit_caseDirectory->setText(data->GetKeyValue(0).toString());*/

	//if (createNew == false)
	//{
	//	CaseSelectionPage::currentCase = GetInfo();
	//	CaseSelectionPage::currentCase.case_id = caseSelectionPage->currentCaseId;
	//	caseSelectionPage->updateCase(CaseSelectionPage::currentCase);
	//	caseSelectionPage->refreshTableWidget();
	//}
	//
	//this->accept();
}

//casetable_tuple QMedicalRecordInfoDialog::GetInfo()
//{
// MITK_INFO << "QMedicalRecordInfoDialog:" << __func__ << ": log";
//	Log::write("QMedicalRecordInfoDialog::GetInfo");
//	casetable_tuple tp;
//
//	tp.patient_name		= m_Controls->lineEdit_patientName->text();
//	tp.patient_id		= m_Controls->lineEdit_patientID->text();
//	tp.patient_gender	= m_Controls->comboBox_patientGender->currentText();
//	tp.patient_age		= m_Controls->lineEdit_patientAge->text().toInt();
//	tp.surgery_side		= m_Controls->comboBox_surgerySide->currentText();
//	tp.surgery_operator = m_Controls->lineEdit_surgeryOperator->text();
//	tp.case_dir			= m_Controls->lineEdit_caseDirectory->text();
//	return tp;
//}
QStringList QMedicalRecordInfoDialog::GetKeys() const
{
	return {
		QPropertyKeys::Name,
		QPropertyKeys::Id,
		QPropertyKeys::Sex,
		QPropertyKeys::Age,
		QPropertyKeys::OperatingSurgeonName,
		QPropertyKeys::SurgicalArea,
		QPropertyKeys::CreateTime
	};
}
void QMedicalRecordInfoDialog::GetInfo(int id, lancet::IMedicalRecordsProperty* data)
{
	if (!data && id < 0)
	{
		return;
	}
	// data items
	QStringList listKey = this->GetKeys();
	for (auto index = 0; index < listKey.size(); ++index)
	{
		m_Controls->lineEdit_patientName->setText(data->GetKeyValue(listKey[1]).toString());
		m_Controls->lineEdit_patientID->setText(data->GetKeyValue(listKey[2]).toString());
		m_Controls->comboBox_patientGender->setCurrentIndex(0);
		m_Controls->lineEdit_patientAge->setText(data->GetKeyValue(listKey[4]).toString());
		m_Controls->comboBox_surgerySide->setCurrentIndex(0);
		m_Controls->lineEdit_surgeryOperator->setText(data->GetKeyValue(listKey[7]).toString());
		m_Controls->lineEdit_caseDirectory->setText(data->GetKeyValue(listKey[11]).toString());
	}
}
//void QMedicalRecordInfoDialog::ModifyInfo(int row,lancet::IMedicalRecordsProperty* data)
//{
	//if (!data || (row + 1) >= this->m_Controls.tableWidget->rowCount() &&
	//	row < 0)
	//{
	//	return;
	//}
	//if (!data->GetKeyValue(QPropertyKeys::Valid).toBool())
	//{
	//	// visible: false
	//	this->m_Controls.tableWidget->removeRow(row);
	//}
	//else
	//{
	//	// items modify
	//	QStringList listKey = this->GetTableWidgetHeaders();
	//	for (auto index = 0; index < listKey.size(); ++index)
	//	{
	//		QTableWidgetItem* cell_row_index = this->m_Controls.tableWidget->item(row, index + 1);
	//		if (cell_row_index)
	//		{
	//			cell_row_index->setText(data->GetKeyValue(listKey[index]).toString());
	//		}
	//	}
	//}
//}
void QMedicalRecordInfoDialog::Slot_MedicalRecordsPropertyTrace(
	int index, lancet::IMedicalRecordsProperty* data, bool valid)
{
	qDebug() << __FUNCTION__ << "\n"
		<< "index: " << index << "\n"
		<< "valid: " << valid << "\n"
		<< "data: " << data->ToString();
	if (data && valid)
	{
		if (data->GetKeyValue(QPropertyKeys::Valid).toBool())
		{
			// Visible: true
			this->GetInfo(0, data);
		}
		data->ResetPropertyOfModify();
	}
}