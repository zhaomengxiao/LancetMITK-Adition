#ifndef QMedicalRecordInfoDialog_H
#define QMedicalRecordInfoDialog_H

#include <QDialog>
class QmitkStdMultiWidget;
class QMedicalRecordManagementEditorPrivate;

namespace lancet
{
	class IMedicalRecordsProperty;
	class IMedicalRecordsAdministrationService;
}
namespace Ui
{
	class QMedicalRecordInfoDialog;
}
class QMedicalRecordInfoDialog : public QDialog
{
    Q_OBJECT
public:
	QMedicalRecordInfoDialog(QWidget* parent = nullptr);
	~QMedicalRecordInfoDialog() override;

	//void SetInfo(casetable_tuple info);

	void CreateInfo(int, lancet::IMedicalRecordsProperty*);
	void ModifyInfo(int, lancet::IMedicalRecordsProperty*);
	void clearData();

	//casetable_tuple GetInfo();

	//CaseSelectionPage* caseSelectionPage;
	bool createNew = false;
protected:
	QStringList GetKeys() const;
	void GetInfo(int, lancet::IMedicalRecordsProperty*);
	//void ModifyInfo(int, lancet::IMedicalRecordsProperty*);
protected Q_SLOTS:
	void Slot_MedicalRecordsPropertyTrace(int, lancet::IMedicalRecordsProperty*, bool);
	//void Slot_MedicalRecordsPropertyModify(int, lancet::IMedicalRecordsProperty*, bool);
private slots:
	void on_pushButton_done_clicked();
	void on_pushButton_browse_clicked();

signals:
	void Caseupdata();

private:
	Ui::QMedicalRecordInfoDialog* m_Controls;
};

#endif // QMedicalRecordInfoDialog_H
