/*============================================================================

The Medical Imaging Interaction Toolkit (MITK)

Copyright (c) German Cancer Research Center (DKFZ)
All rights reserved.

Use of this source code is governed by a 3-clause BSD license that can be
found in the LICENSE file.

============================================================================*/


// Blueberry
#include <berryISelectionService.h>
#include <berryIWorkbenchWindow.h>

// Qmitk
#include "QMedicalRecordManagement.h"

// Qt
#include <QDir>
#include <QMessageBox>

// mitk image
#include <mitkImage.h>

#include <lancetIMedicalRecordsScanner.h>
#include <lancetIMedicalRecordsProperty.h>
#include <lancetIMedicalRecordsAdministrationService.h>

#include "org_mitk_lancet_medicalrecordmanagement_Activator.h"

// THA
#include "QMedicalRecordInfoDialog.h"
#include "QMedicalRecordManagement.h"
const std::string QMedicalRecordManagement::VIEW_ID = "org.mitk.views.qmedicalrecordmanagement";

void QMedicalRecordManagement::SetFocus()
{
}
QMedicalRecordManagement::~QMedicalRecordManagement()
{

}
void QMedicalRecordManagement::CreateQtPartControl(QWidget *parent)
{
  // create GUI widgets from the Qt Designer's .ui file
  m_Controls.setupUi(parent); 
  
  auto test_dir = QDir(":/org.mitk.lancet.medicalrecordmanagement/");
  QFile qss(test_dir.absoluteFilePath("medicalrecordmanagement.qss"));
  if (!qss.open(QIODevice::ReadOnly))
  {
	  qWarning() << __func__ << __LINE__ << ":" << "error load file "
		  << test_dir.absoluteFilePath("medicalrecordmanagement.qss") << "\n"
		  << "error: " << qss.errorString();
  }
  // pos
  qInfo() << "log.file.pos " << qss.pos();
  m_Controls.widget->setStyleSheet(QLatin1String(qss.readAll()));
  qss.close();
  this->ConnectToService(); 
  connect(m_Controls.toolButton_new, &QToolButton::clicked, this, &QMedicalRecordManagement::NewMedicalRecordInfoDialog);
  connect(m_Controls.toolButton_open, &QToolButton::clicked, this, &QMedicalRecordManagement::OpenMedicalRecord);
  connect(m_Controls.toolButton_edit, &QToolButton::clicked, this, &QMedicalRecordManagement::modifMedicalRecordInfoDialog);
  connect(m_Controls.toolButton_close, &QToolButton::clicked, this, &QMedicalRecordManagement::CloseMedicalRecord);
}

void QMedicalRecordManagement::OnSelectionChanged(berry::IWorkbenchPart::Pointer /*source*/,
                                                const QList<mitk::DataNode::Pointer> &nodes)
{
  // iterate all selected objects, adjust warning visibility
}

void QMedicalRecordManagement::DoImageProcessing()
{
  QList<mitk::DataNode::Pointer> nodes = this->GetDataManagerSelection();
}

lancet::IMedicalRecordsAdministrationService* QMedicalRecordManagement::GetService() const
{
  auto context = mitk::PluginActivator::GetPluginContext();
	auto serviceRef = context->getServiceReference<lancet::IMedicalRecordsAdministrationService>();
  return context->getService<lancet::IMedicalRecordsAdministrationService>(serviceRef);
}

void QMedicalRecordManagement::ConnectToService()
{
	auto sender = this->GetService();
	if (sender)
	{
		lancet::IMedicalRecordsAdministrationService* o = sender;
		QObject::connect(o, &lancet::IMedicalRecordsAdministrationService::MedicalRecordsPropertySelect,
			this, &QMedicalRecordManagement::Slot_MedicalRecordsPropertySelect);
	}
}

void QMedicalRecordManagement::DisConnectToService()
{
	auto sender = this->GetService();
	if (sender)
	{
		lancet::IMedicalRecordsAdministrationService* o = sender;
		QObject::disconnect(o, &lancet::IMedicalRecordsAdministrationService::MedicalRecordsPropertySelect,
			this, &QMedicalRecordManagement::Slot_MedicalRecordsPropertySelect);
	}
}

void QMedicalRecordManagement::Slot_MedicalRecordsPropertySelect(lancet::IMedicalRecordsProperty* data)
{
  qDebug() << __FUNCTION__ << "\n"
           << "data " << data->ToString();
	if (data)
	{
		data->ResetPropertyOfModify();
	}
}
void QMedicalRecordManagement::NewMedicalRecordInfoDialog()
{
	MITK_INFO << "QMedicalRecordManagement:" << __func__ << ": log";
	m_MedicalRecordInfoDialog = new QMedicalRecordInfoDialog();
	m_MedicalRecordInfoDialog->setWindowTitle("Create A New MedicalRecord");
	m_MedicalRecordInfoDialog->setWindowModality(Qt::ApplicationModal);
	m_MedicalRecordInfoDialog->show();
	m_MedicalRecordInfoDialog->clearData();
	//caseInfo->createNew = true;
	if (QDialog::Rejected == m_MedicalRecordInfoDialog->exec())
	{
		return;
	}
	////Default new case info
	//casetable_tuple tp;// = caseInfo->GetInfo();
	//tp = caseInfo->GetInfo();
	//tp.case_id = this->sql.GenerateUniqueCaseID();
	//tp.case_create_date = QDateTime::currentDateTime();
	//tp.case_update_date = QDateTime::currentDateTime();
	//tp.cup_matrix = "0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0";
	//tp.stem_matrix = "0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0";

	////Create the sql row
	//this->createNewCase(tp);
	//m_newPatientBackups.case_id = tp.case_id;
	//m_newPatientBackups.patient_name = tp.patient_name;
	//ReadBackups::getInStance()->MkNewPatientdir(m_newPatientBackups);
	//this->refreshTableWidget();
}

void QMedicalRecordManagement::modifMedicalRecordInfoDialog()
{
	MITK_INFO << "QMedicalRecordManagement:" << __func__ << ": log";
	m_MedicalRecordInfoDialog = new QMedicalRecordInfoDialog();
	m_MedicalRecordInfoDialog->setWindowTitle("Modif A MedicalRecord");
	m_MedicalRecordInfoDialog->setWindowModality(Qt::ApplicationModal);
	m_MedicalRecordInfoDialog->show();

	//if (list_item.size() == 0)
	//{
	//	QMessageBox::information(this, "��ʾ", "����ѡ��һ��������Ϣ!", "�ر�");
	//	return;
	//}

	//qDebug() << list_item[0]->text();
	//int case_id = m_Controls->tableWidget->item(list_item.at(0)->row(), 0)->text().toInt();

	////Select Label
	//currentCase = this->sql.GetCaseTuple(case_id);
	//currentCaseId = case_id;
	//caseInfo->createNew = false;

	//caseInfo->SetInfo(currentCase);

	//int ret = caseInfo->exec();
	//if (ret == QDialog::Rejected)
	//{
	//	return;
	//}
}
void QMedicalRecordManagement::OpenMedicalRecord()
{
	MITK_INFO << "QMedicalRecordManagement:" << __func__ << ": log";
	this->setCaseOpened(false);
	//this->closeCase();
}
void QMedicalRecordManagement::CloseMedicalRecord()
{
	MITK_INFO << "QMedicalRecordManagement:" << __func__ << ": log";
}
void QMedicalRecordManagement::closeCase()
{
	MITK_INFO << "QMedicalRecordManagement:" << __func__ << ": log";
	mitk::DataStorage* ds = mitk::RenderingManager::GetInstance()->GetDataStorage();
	mitk::DataStorage::SetOfObjects::ConstPointer all =
		ds->GetAll();
	for (mitk::DataNode::Pointer data : *all) {
		ds->Remove(data);
	}
}
void QMedicalRecordManagement::setCaseOpened(bool b)
{
	//Update Table
	//this->ui->tableWidget->setEnabled(!b);
	//this->ui->tableWidget->clearSelection();

	//Enable + Disable Button
	m_Controls.toolButton_new->setEnabled(!b);
	m_Controls.toolButton_open->setEnabled(!b);
	m_Controls.toolButton_edit->setEnabled(!b);
	m_Controls.toolButton_close->setEnabled(b);

	isClose = b;
}