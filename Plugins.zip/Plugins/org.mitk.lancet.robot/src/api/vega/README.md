# vegaapi

*   Author: WUZHUOBIN jiejin2022@163.com
*   Copyright: &copy;WUZHUOBIN ALL RIGHT RESERVED.
*   Since: Mar.29rd.2020

* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
>			This program is distributed in the hope that it will be useful, but
>			WITHOUT ANY WARRANTY; without even the implied warranty of
>			MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
>			See the LICENSE for more detail.
>			Copyright (c) WUZHUOBIN. All rights reserved.
>			See COPYRIGHT for more detail.
>			This software is distributed WITHOUT ANY WARRANTY; without even
>			the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
>			PURPOSE.  See the above copyright notice for more information.
>			Internal usage only, without the permission of the author, please DO
>			NOT publish and distribute without the author's permission.
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
